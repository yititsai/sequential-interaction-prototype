# Study: Charge + Burst

Source: `index.html` (single self-contained file, 447 lines; line numbers below refer to it).

## What it does
A soft, elastic grey form rests on a wide lower platform with a narrower platform a short hop above. Holding two fingers (touch), pressing and holding the mouse, or holding Space charges it: it swells, vibrates, and a ring fills around it. At full charge (1 s) it bursts upward and lands on the upper platform. A **Reset** link (top-right) returns it to the lower platform.

## Main visual and interactive components
| Component | What it is |
|---|---|
| Canvas (`#c`) | Full-screen canvas drawing everything |
| Platforms | Wide lower platform and narrower upper platform, centered |
| Player form | Elastic blob drawn from an inline SVG data URI (gradient, soft highlight, outline), with an ellipse fallback while it loads |
| Contact markers | Two circles flanking the form representing the two touches; faint at rest, dark/smaller when held |
| Charge ring | Thin ellipse around the form that fills as the hold builds, with a dot at the leading edge |
| Burst/landing rings | Short-lived flat ellipses at the feet |
| Motion trail | Three short streaks under the form on the way up |
| Reset (`#reset`) | Text button, top-right |

## User actions, feedback, states, transitions
**States:** `idle` (resting, possibly charging) and `flight`. Charging is `idle` with charge > 0. An "armed" flag requires a fresh press for each charge. Reset is disabled until the first charge begins.

| Action | Feedback / transition |
|---|---|
| Hold (two touches, mouse button, or Space) | Quick press-down squash; then the form swells (up to +45%), pulse speeds up and deepens, vibration grows, markers darken, charge ring fills over `HOLD` = 1.0 s |
| Release too early | Charge eases back down (0.8/s), size settles, no launch |
| Charge reaches 100% | Launches automatically (no release needed): stretch, burst ring, first trail streaks |
| Flight | Gravity arc; stretch follows vertical speed; streaks emitted while rising fast; grow decays |
| Landing | Squash, landing ring; from the lower platform it clears and lands on the upper one; from the upper platform it hops in place and lands on it again |
| Keep holding after landing | No new charge until all input is released (armed flag) |
| Reset click | Back to the lower platform, all effects cleared, Reset disables (Reset presses do not count as holds) |
| Resize | Layout recomputed; flight is cancelled and the form snaps to its current platform |
| Window blur / context menu | Holds cleared / context menu suppressed |

Reduced motion: no trail, no vibration, smaller pulse, squash x0.4.

## Where things are implemented (`index.html`)
- Design tokens, light/dark: lines 5-29
- Canvas and Reset styling: lines 45-72
- Markup: lines 75-76
- Player art (SVG data URI) and shape constants: lines 85-109
- Theme color sync (`readColors`): 111-123
- Geometry and platform layout (`layout`): 127-153
- State variables: 155-175; `platTop` (177); `hardReset` (179); `relayout` (195)
- Input (touch count, mouse, Space, blur, Reset): 208-236
- Launch and landing (`launch`, `land`): 238-259
- Charge logic, pulse, flight physics, trail/rings, squash spring (`update`): 262-330
- Rendering: platforms, trail, rings, contact markers, player, vibration, charge ring (`draw`): 333-435
- Main loop (`frame`): 437-444

## External dependencies and assets
None. No network requests, libraries, fonts, or image files (art is an inline SVG data URI). System font stack only. Needs a modern browser with Canvas 2D (`ctx.ellipse`), Pointer Events (multi-touch), `MutationObserver`.
Dark mode follows the OS setting; `<html data-theme="light|dark">` can force a theme, but nothing in this file sets it.
Note: the two-finger gesture needs a touch device; on desktop use mouse press-and-hold or Space.

## Run it
Open `index.html` in a browser, or serve the folder (`python3 -m http.server`) and visit it.
