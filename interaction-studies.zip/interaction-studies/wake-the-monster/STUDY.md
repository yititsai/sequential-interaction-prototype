# Study: Wake the Monster

Source: `index.html` (single self-contained file, 356 lines; line numbers below refer to it).

## What it does
A single soft, grey, blob-shaped character sits alone in the center of an empty field, dormant (washed-out, low contrast). Pressing and releasing it squishes it, wakes it up (full contrast), and sends a thin ripple outward. After that it can be squished again for another ripple. A small **Reset** link returns it to the dormant state.

## Main visual and interactive components
| Component | What it is |
|---|---|
| Character (`#character`) | Focusable `role="button"` wrapper, sized by `--size` (`min(64vmin, 360px)`) |
| Body (`#body`) | Inline SVG blob with radial gradient, sag gradient, blurred highlight, and an outline path (`.edge`) |
| Hit area (`#hit`) | Transparent copy of the blob path; only presses on the blob shape count (not the bounding box) |
| Ripple (`.ripple`) | Thin circular border element created on demand, animated outward and faded |
| Reset (`#reset`) | Text button, bottom-right |
| Live region (`#live`) | Visually hidden `aria-live` text announcing "Awake" / "Dormant" |

## User actions, feedback, states, transitions
**States:** dormant (initial) -> awake. Transient sub-states: hover, pressed.

| Action | Feedback / transition |
|---|---|
| Hover (mouse only) | Outline thickens (3px -> 5.5px) and darkens |
| Press and hold (pointer on blob, or Space/Enter when focused) | Body squashes (wider, shorter) via a stiff spring; outline goes to the pressed style |
| Release | Spring relaxes with one soft overshoot; a quick tap still squashes to at least 70% before rebounding (`MIN_SQUASH`); a ripple starts 140 ms later and expands to 165% while fading over 1.7 s |
| First release | Also triggers wake: the dormant filter fades out over 0.9 s, outline darkens, aria-label changes to "awake", Reset enables |
| Later presses | Same squash + ripple; stays awake |
| Reset click | Back to dormant (filter returns, ripples removed, label restored), Reset disables |
| Idle | Continuous breathing scale: slower/shallower when dormant (4.6 s period), livelier when awake (3.2 s) |
| Focus loss / window blur while pressed | Treated as release |

Reduced motion: no breathing, no minimum squash hold, shorter and smaller ripple (500 ms to 96%), near-instant CSS transitions.
Theming: light by default; dark via `prefers-color-scheme` (see Dependencies).

## Where things are implemented (`index.html`)
- Design tokens, light/dark values: lines 5-42 (`:root`, dark media query, `[data-theme="dark"]`)
- Dormant vs awake filter: `--dorm-filter`, lines 85-92 (`.body svg`, `.character.awake .body svg`)
- Hover/pressed/focus outline styles: lines 94-108
- Ripple styling: lines 110-121
- Reset button styling: lines 123-141; reduced-motion overrides: 153-155
- Markup (character, SVG blob, hit path, live region, Reset): lines 158-191
- Squash spring + press/release logic: `press` (216), `requestRelease` (226), `doRelease` (232)
- Wake state change: `wake()` (244)
- Ripple animation (Web Animations API): `ripple()` (252)
- Reset logic: `resetAll()` (267)
- Pointer, keyboard, blur handlers: lines 284-317
- Animation loop (spring integration at 240 Hz, breathing, transform): `frame()` (324-351)

## External dependencies and assets
None. No network requests, libraries, fonts, or image files; the character is inline SVG. Font stack is system "Helvetica Neue, Helvetica, Arial, sans-serif". Needs a modern browser with Pointer Events, Web Animations (`element.animate`), CSS `aspect-ratio`, `inset`, and `:focus-visible`.
Dark mode follows the OS setting; `<html data-theme="light|dark">` can force a theme, but nothing in this file sets it.

## Run it
Open `index.html` in a browser, or serve the folder (`python3 -m http.server`) and visit it.
