# Study: Steer + Fire

Source: `index.html` (single self-contained file, 457 lines; line numbers below refer to it).

## What it does
A small grey circle stands on a floor with three floating bars above it. The player moves left/right, jumps between platforms, and fires projectiles straight up. An on-screen key row (arrows + space bar) mirrors the keyboard and works with touch/mouse. A **Reset** link (top-right) returns the circle to the start.

## Main visual and interactive components
| Component | What it is |
|---|---|
| Play area (`<canvas id="c">`) | Full-screen canvas drawing platforms, player, projectiles, rings |
| Platforms | Full-width floor plus three bars at staggered heights/positions (computed from layout) |
| Player | Grey circle drawn from an inline SVG data URI (with a canvas-drawn fallback while it loads), squashed/stretched from the feet |
| Projectiles | Small dark ellipses that burst out fast then cruise upward, with a short tail while fastest |
| Rings | Brief expanding outline rings on fire and on jump |
| Key row (`#keys`) | Left, Up, Right key caps and a wide Space cap |
| Reset (`#reset`) | Text button, top-right |

## User actions, feedback, states, transitions
**States:** grounded / airborne; Reset disabled until the first input ("dirty" flag).

| Action | Feedback / transition |
|---|---|
| ArrowLeft / ArrowRight (keyboard or on-screen key) | Near-instant horizontal move; circle leans (skews) into travel direction; clamped to screen edges |
| ArrowUp | Jump (with 70 ms coyote time and 100 ms jump buffer); stretch on takeoff, small ring under the feet; squash on landing |
| Space | Fires a projectile upward (rate-limited to one per 70 ms); body recoil-squash (stronger on the ground), a small ring at the muzzle; airborne shots also kick the circle downward slightly |
| Key pressed (physical or touch) | On-screen cap inverts colors and drops 3 px |
| Projectile leaves the top | Removed |
| Window blur | All keys released |
| Resize | Layout recomputed; player keeps its relative position and may drop |
| Reset click | Player returns to center on the floor; shots and rings cleared; Reset disables |

Physics: gravity, one-way platforms (land only when falling and overlapping horizontally), jump height scales with platform spacing. Squash/recoil use spring integration at 240 Hz.
Reduced motion: squash and fx are reduced (squash x0.4, no lean skew, half-strength rings/tails).

## Where things are implemented (`index.html`)
- Design tokens, light/dark: lines 5-32
- Key cap and Reset styling: lines 56-119
- Markup (canvas, key row, Reset): lines 122-133
- Player art (SVG data URI): lines 143-149
- Theme color sync to canvas (`readColors`): 151-164
- Geometry, platforms, physics constants (`layout`): 168-198
- State variables: 200-210; `resetPlayer` (212); `relayout` (223)
- Input (`press`, `release`, keyboard, blur, on-screen keys, Reset): 239-296
- Fire action (`fire`): 299-308
- Physics, movement, jump, landing, spring updates, shots/rings aging (`update`): 311-380
- Rendering (platforms, rings, projectiles, player transform) (`draw`): 382-445
- Main loop (`frame`): 447-454

## External dependencies and assets
None. No network requests, libraries, fonts, or image files (the player art is an inline SVG data URI). System font stack only. Needs a modern browser with Canvas 2D (`ctx.ellipse`), Pointer Events, `MutationObserver`.
Dark mode follows the OS setting; `<html data-theme="light|dark">` can force a theme (the canvas colors re-read on change), but nothing in this file sets it.
Keyboard focus note: Space/arrow keys are captured on `window` with `preventDefault`.

## Run it
Open `index.html` in a browser, or serve the folder (`python3 -m http.server`) and visit it. Touch devices use the on-screen keys.
