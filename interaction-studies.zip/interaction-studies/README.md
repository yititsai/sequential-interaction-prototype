# Interaction studies

Four standalone studies. Each folder has the complete source (`index.html`) and a `STUDY.md` describing it.

| Folder | Study | Primary input |
|---|---|---|
| `wake-the-monster/` | Press to squish and wake a dormant character, ripple on release | Press/hold, Space/Enter |
| `steer-and-fire/` | Move, jump, and fire a circle with on-screen key caps | Arrow keys, Space |
| `glide-to-steer/` | Floating circle glides toward the pointer | Pointer x, arrow keys |
| `charge-and-burst/` | Hold to charge, burst upward onto a higher platform | Two touches / mouse hold / Space |

## Setup
No build step, package install, or external assets. Open a study's `index.html` in a modern browser, or serve this folder:

    python3 -m http.server 8000   # then visit http://localhost:8000/<folder>/

## Notes for combining studies
- Each file is a self-contained page with one IIFE script; all state is private to that IIFE.
- Each registers listeners on `window` and uses fixed-position elements with the same ids (`#reset`, `#c`, SVG gradient ids). Running two in one document will collide, so load them one at a time (separate pages, iframes, or refactor into modules with scoped roots).
- Shared conventions: the same light/dark design tokens (`--bg`, `--fg`, `--muted`, platform colors), a text **Reset** link that stays disabled until the first input, `prefers-reduced-motion` handling, and spring-based squash/stretch animation.
- Each `index.html` begins with a small host-injected baseline `<style>` (safe-area padding, default font) and has `<title>` inside `<body>`; kept as published so behavior is unchanged.
