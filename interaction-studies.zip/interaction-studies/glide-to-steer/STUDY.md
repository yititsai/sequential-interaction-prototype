# Study: Glide to Steer

Source: `index.html` (single self-contained file, 250 lines; line numbers below refer to it).

## What it does
A soft grey circle floats a little above the center of an empty field, bobbing gently, with a blurred shadow on an invisible floor beneath it. Moving the pointer left or right makes the circle glide horizontally toward it like it is on a soft spring, leaning into the motion. A **Reset** link (bottom-right) recenters it.

## Main visual and interactive components
| Component | What it is |
|---|---|
| Field (`#field`) | Full-screen pointer-tracking surface |
| Token (`#token`) | Floating circle, inline SVG (radial gradient + outline), sized by `--d` (`min(30vmin, 200px)`) |
| Shadow (`#shadow`) | Inline SVG ellipse with radial gradient; scales and fades with the bob |
| Reset (`#reset`) | Text button, bottom-right |

## User actions, feedback, states, transitions
**States:** idle (no input yet, Reset disabled) -> steering (Reset enabled). Motion "energy" smoothly blends between calm float and busy steering.

| Action | Feedback / transition |
|---|---|
| Move pointer horizontally (any pointer, no press needed) | Circle glides toward the pointer's x with a soft spring (lazy, floaty); target is lightly smoothed to remove jitter and clamped inside the screen |
| Pointer down | Also sets the target |
| ArrowLeft / ArrowRight | Shifts the target by 9% of screen width per press (keyboard alternative) |
| While gliding | Circle rotates (up to 18 deg) into the direction of travel using a second spring; subtle squash/stretch with speed; shadow widens slightly |
| Idle / calm | Slow, deeper vertical bob (~3.8 s) plus slight horizontal sway and idle lean; while steering the bob gets quicker and shallower, and sway fades |
| Bob up | Shadow shrinks and fades; bob down, it grows |
| Reset click | Target returns to center (circle glides back); Reset disables until next input |
| Resize | Layout and clamping recomputed |

Only horizontal pointer position is used; vertical position is fixed (`baseY` = 45% of height).
Reduced motion: smaller bob, no sway/idle lean/lean-on-travel/speed stretch, critically damped springs.

## Where things are implemented (`index.html`)
- Design tokens, light/dark: lines 5-30
- Token, shadow, Reset styling: lines 53-95
- Markup (shadow SVG, token SVG, Reset): lines 97-122
- State variables (springs, phases, energy): lines 125-142
- Clamping and layout/measure (`limitX`, `measure`): 145-168
- Input: `aim` (170), pointer listeners (174-175), arrow keys (178-181), Reset (183-190)
- Spring simulation, bob/sway/lean/energy, token and shadow transforms (`frame`): 195-245
- Loop start: 247

## External dependencies and assets
None. No network requests, libraries, fonts, or image files; all art is inline SVG. System font stack only. Needs a modern browser with Pointer Events and CSS `inset`.
Dark mode follows the OS setting (shadow opacity is tuned via `--shadow-a/--shadow-b`); `<html data-theme="light|dark">` can force a theme, but nothing in this file sets it.

## Run it
Open `index.html` in a browser, or serve the folder (`python3 -m http.server`) and visit it. Move the pointer (or use the left/right arrow keys).
